-- cantidad de pacientes de cada obra social
select      obra_social, COUNT(*) cantidad
from        pacientes
group by    obra_social;

-- nomnbres y apellidos de medicos, ordenados según su especialidad
select      especialidad, nombre, apellido
from        medicos
order by    especialidad;

-- medicos con más de un turno
select     m.nombre, m.apellido, count(t.id_turno) cantidad_turnos
from       medicos m
join       turnos t 
on         m.id_medico = t.id_medico
group by   m.id_medico
having     cantidad_turnos > 1;

-- turnos para una fecha especifica
select      t.fecha, t.horario, p.nombre paciente, m.nombre medico, t.motivo
from        turnos t
join        pacientes p 
on          t.id_paciente = p.id_paciente
join        medicos m 
on          t.id_medico = m.id_medico
where       t.fecha = '2025-06-14';

-- receta de un paciente en particular
select      r.fecha_emision, r.diagnostico, m.nombre medico
from        recetas r
join        medicos m 
on          r.id_medico = m.id_medico
where       r.id_paciente = 1;

-- cantidad de las veces que se receto cada medicamento 
select      m.nombre_comercial, COUNT(*) veces_recetado
from        recetas_medicamentos rm
join        medicamentos m 
on          rm.id_medicamento = m.id_medicamento
group by    m.id_medicamento;