package clinica_medica.com.ar.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import clinica_medica.com.ar.entities.Medicamento;
import clinica_medica.com.ar.repositories.interfaces.I_MedicamentoRepository;

@Repository
public class MedicamentoDAO implements I_MedicamentoRepository{

    private final DataSource dataSource;

    private static final String SQL_CREATE =
        "INSERT INTO medicamentos (nombre_comercial, droga, descripcion, presentacion) VALUES (?, ?, ?, ?)";
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM medicamentos WHERE id_medicamento = ?";
    private static final String SQL_FIND_ALL =
        "SELECT * FROM medicamentos";
    private static final String SQL_UPDATE =
        "UPDATE medicamentos SET nombre_comercial = ?, droga = ?, descripcion = ?, presentacion = ? WHERE id_medicamento = ?";
    private static final String SQL_DELETE =
        "DELETE FROM medicamentos WHERE id_medicamento = ?";
    private static final String SQL_FIND_BY_DROGA =
        "SELECT * FROM medicamentos WHERE droga LIKE ?";

    public MedicamentoDAO(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(Medicamento medicamento) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
        
            ps.setString(1, medicamento.getNombreComercial());
            ps.setString(2, medicamento.getDroga());
            ps.setString(3, medicamento.getDescripcion());
            ps.setString(4, medicamento.getPresentacion());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    medicamento.setIdMedicamento(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Medicamento findById(int idMedicamento) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, idMedicamento);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Medicamento> findAll() throws SQLException {
        List<Medicamento> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        }
        return lista;
    }

    @Override
    public int update(Medicamento medicamento) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {

            ps.setString(1, medicamento.getNombreComercial());
            ps.setString(2, medicamento.getDroga());
            ps.setString(3, medicamento.getDescripcion());
            ps.setString(4, medicamento.getPresentacion());
            ps.setInt(5, medicamento.getIdMedicamento());
            int filasAfectadas = ps.executeUpdate(); 
            return filasAfectadas; 
        }
    }

    @Override
    public int delete(int idMedicamento) throws SQLException {
         try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, idMedicamento);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        } 
    }

    @Override
    public List<Medicamento> findByDroga(String droga) throws SQLException {
        List<Medicamento> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_DROGA)) {
            ps.setString(1,droga);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    private Medicamento mapRow(ResultSet rs) throws SQLException {
        Medicamento medicamento = new Medicamento();
        medicamento.setIdMedicamento(rs.getInt("id_medicamento"));
        medicamento.setNombreComercial(rs.getString("nombre_comercial"));
        medicamento.setDroga(rs.getString("droga"));
        medicamento.setDescripcion(rs.getString("descripcion"));
        medicamento.setPresentacion(rs.getString("presentacion"));
        return medicamento;
    }
}
