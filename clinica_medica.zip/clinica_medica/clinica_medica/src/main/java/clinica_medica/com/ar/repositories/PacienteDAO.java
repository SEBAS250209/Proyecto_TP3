package clinica_medica.com.ar.repositories;

import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import clinica_medica.com.ar.entities.Paciente;
import clinica_medica.com.ar.repositories.interfaces.I_PacienteRepository;

@Repository
public class PacienteDAO implements I_PacienteRepository{

     private final DataSource dataSource ;
     
     private static final String SQL_CREATE = 
         "INSERT INTO paciente (idPaciente, nombre, apellido, genero, dni, telCelular, email, idHistoria, obraSocial) values (?,?,?,?,?,?,?,?,?)";
          //los signos de interrogación son marcadores de posición para los valores que
          //se establecerán más adelante
     private static final String SQL_FIND_BY_ID =
        "SELECT * FROM alumnos WHERE id=?";
     private static final String SQL_FIND_ALL = 
        "SELECT * FROM alumnos";
     private static final String SQL_UPDATE =
        "UPDATE alumnos SET nombre=?, apellido=?, edad=?, idCurso=?, activo=? WHERE id=?";
     private static final String SQL_DELETE = 
        "DELETE FROM alumnos WHERE id=?";
     private static final String SQL_FIND_BY_CURSO = 
        "SELECT * FROM alumnos WHERE idCurso=?";
    

     public PacienteDAO(DataSource dataSource) {
        this.dataSource = dataSource;
     }

     @Override
     public void create(Paciente paciente) throws SQLException {
          // TODO Auto-generated method stub
          throw new UnsupportedOperationException("Unimplemented method 'create'");
     }

     @Override
     public Paciente findById(int id) throws SQLException {
          // TODO Auto-generated method stub
          throw new UnsupportedOperationException("Unimplemented method 'findById'");
     }

     @Override
     public List<Paciente> findAll() throws SQLException {
          // TODO Auto-generated method stub
          throw new UnsupportedOperationException("Unimplemented method 'findAll'");
     }

     @Override
     public int update(Paciente paciente) throws SQLException {
          // TODO Auto-generated method stub
          throw new UnsupportedOperationException("Unimplemented method 'update'");
     }

     @Override
     public int delete(int id) throws SQLException {
          // TODO Auto-generated method stub
          throw new UnsupportedOperationException("Unimplemented method 'delete'");
     }

   

}
