package clinica_medica.com.ar.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import clinica_medica.com.ar.entities.Paciente;
import clinica_medica.com.ar.repositories.interfaces.I_PacienteRepository;

@Repository
public class PacienteDAO implements I_PacienteRepository{

    private final DataSource dataSource ;
     
    private static final String SQL_CREATE = 
        "INSERT INTO pacientes (nombre, apellido, genero, dni, tel_celular, email, id_historia, obra_social) values (?,?,?,?,?,?,?,?)";
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM pacientes WHERE id_paciente=?";
    private static final String SQL_FIND_ALL = 
        "SELECT * FROM pacientes";
    private static final String SQL_UPDATE =
        "UPDATE pacientes SET nombre=?, apellido=?, genero=?, dni=?, tel_celular=?, email=?, id_historia=?, obra_social=? WHERE id_paciente=?";
    private static final String SQL_DELETE = 
        "DELETE FROM pacientes WHERE id_paciente=?";
    private static final String SQL_FIND_BY_HISTORIA = 
        "SELECT * FROM pacientes WHERE id_historia=?";
     

     public PacienteDAO(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(Paciente paciente) throws SQLException {
        try (Connection conn = dataSource.getConnection();
            PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, paciente.getNombre());
            ps.setString(2, paciente.getApellido());
            ps.setString(3, paciente.getGenero());
            ps.setString(4, paciente.getDni());
            ps.setString(5, paciente.getTelCelular());
            ps.setString(6, paciente.getEmail());
            ps.setInt(7,paciente.getIdHistoria());
            ps.setString(8,paciente.getObraSocial());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if(keys.next()){
                    paciente.setIdPaciente(keys.getInt(1));
                }
            } 
        } 
     }

    @Override
    public Paciente findById(int idPaciente) throws SQLException {
        try (Connection conn = dataSource.getConnection();
            PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, idPaciente);
            try (ResultSet rs = ps.executeQuery()) {
                if(rs.next()){
                    return mapRow(rs);
                }
            } 
        } 
        return null;
     }

    @Override
    public List<Paciente> findAll() throws SQLException {
        List<Paciente> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
            PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()){
            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        } 
        return lista;
     }

    @Override
    public int update(Paciente paciente) throws SQLException {
          try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, paciente.getNombre());
            ps.setString(2, paciente.getApellido());
            ps.setString(3, paciente.getGenero());
            ps.setString(4, paciente.getDni());
            ps.setString(5, paciente.getTelCelular());
            ps.setString(6,paciente.getEmail());
            ps.setInt(7, paciente.getIdHistoria());
            ps.setString(8,paciente.getObraSocial());
            ps.setInt(9,paciente.getIdPaciente());
            int filasAfectadas = ps.executeUpdate(); 
            return filasAfectadas; 
        }
     }

     @Override
     public int delete(int idPaciente) throws SQLException {
          try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, idPaciente);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        } 
     }

     @Override
     public List<Paciente> findByHistoria(int idHistoria) throws SQLException {
         List<Paciente> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_HISTORIA)) {
            ps.setInt(1, idHistoria);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            } 
        } 
        return lista;
     }

     private Paciente mapRow(ResultSet rs) throws SQLException{
        Paciente paciente = new Paciente();
        paciente.setIdPaciente(rs.getInt("id_paciente"));
        paciente.setNombre(rs.getString("nombre"));
        paciente.setApellido(rs.getString("apellido"));
        paciente.setGenero(rs.getString("genero"));
        paciente.setDni(rs.getString("dni"));
        paciente.setTelCelular((rs.getString("tel_celular")));
        paciente.setEmail((rs.getString("email")));
        paciente.setIdHistoria((rs.getInt("id_historia")));
        paciente.setObraSocial((rs.getString("obra_social")));
        return paciente;
    }

     
     

}
