package clinica_medica.com.ar.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Medicamento {
private int idMedicamento;
private String nombreComercial;
private String droga;
private String descripcion;
private String presentacion;


}
