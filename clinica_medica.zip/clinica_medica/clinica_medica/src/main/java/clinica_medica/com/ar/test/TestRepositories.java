package clinica_medica.com.ar.test;

import java.time.LocalDate;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import clinica_medica.com.ar.entities.Medicamento;
import clinica_medica.com.ar.entities.Medico;
import clinica_medica.com.ar.entities.Paciente;
import clinica_medica.com.ar.entities.Receta;
import clinica_medica.com.ar.entities.RecetaMedicamento;
import clinica_medica.com.ar.repositories.MedicamentoDAO;
import clinica_medica.com.ar.repositories.MedicoDAO;
import clinica_medica.com.ar.repositories.PacienteDAO;
import clinica_medica.com.ar.repositories.RecetaDAO;
import clinica_medica.com.ar.repositories.RecetaMedicamentoDAO;
import clinica_medica.com.ar.repositories.TurnoDAO;
import clinica_medica.com.ar.repositories.interfaces.I_MedicamentoRepository;
import clinica_medica.com.ar.repositories.interfaces.I_MedicoRepository;
import clinica_medica.com.ar.repositories.interfaces.I_PacienteRepository;
import clinica_medica.com.ar.repositories.interfaces.I_RecetaMedicamentoRepository;
import clinica_medica.com.ar.repositories.interfaces.I_RecetaRepository;
import clinica_medica.com.ar.repositories.interfaces.I_TurnoRepository;

@SpringBootApplication(scanBasePackages = "clinica_medica.com.ar")
public class TestRepositories {
public static void main(String[] args) {
        try (ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class, args)) {

            I_PacienteRepository pacienteDAO = context.getBean(PacienteDAO.class);
            I_MedicoRepository medicoDAO = context.getBean(MedicoDAO.class);
            I_MedicamentoRepository medicamentoDAO = context.getBean(MedicamentoDAO.class);
            I_RecetaRepository recetaDAO = context.getBean(RecetaDAO.class);
            I_TurnoRepository turnoDAO = context.getBean(TurnoDAO.class);
            I_RecetaMedicamentoRepository recetaMedDAO = context.getBean(RecetaMedicamentoDAO.class);

            // ======= PACIENTE TESTS =======
            System.out.println("\n>>> Test PacienteDAO");
            Paciente nuevoPaciente= new Paciente(0, "Ana", "García", "Femenino", "12345678", "11112222", "ana@mail.com", 1, "OSDE");
            pacienteDAO.create(nuevoPaciente);
            System.out.println("Paciente creado: " + nuevoPaciente);
            
            // BUSCAR POR ID
            System.out.println("\n Buscando paciente por ID " + nuevoPaciente.getIdPaciente() + "...");
            Paciente pacienteEncontrado = pacienteDAO.findById(nuevoPaciente.getIdPaciente());
            if(pacienteEncontrado!=null){
                System.out.println(" ## Paciente encontrado: " + pacienteEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró el paciente con el ID " + nuevoPaciente.getIdPaciente());
            }

            // MODIFICAR
            System.out.println("Modificar un paciente");
            nuevoPaciente.setNombre("Rosio Peréz");
            int filasAfectadas = pacienteDAO.update(nuevoPaciente);
            if(filasAfectadas==1){
                System.out.println(" ## Paciente " + nuevoPaciente.getIdPaciente() + "actualizado correctamente");
                System.out.println(" ## Verificando actualización: " + pacienteDAO.findById(nuevoPaciente.getIdPaciente()));
            } else {
                System.err.println(" ¡¡ ERROR -  No se pudo actualizar al paciente !!");
            }
            
            // LISTAR PACIENTES
            System.out.println("\n Listando todos los pacientes...");
            List<Paciente> pacientesTodos = pacienteDAO.findAll();
            if(!pacientesTodos.isEmpty()){
                System.out.println(" ## Pacientes encontrados: " + pacientesTodos.size());
                pacientesTodos.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron pacientes");
            }

            // ======= MEDICO TEST =======
            System.out.println("\n>>> Test MedicoDAO");
            Medico nuevomeMedico= new Medico(0, "Carlos", "Sánchez", "87654321", "Cardiología", 12345, "11223344", "carlos@mail.com");
            medicoDAO.create(nuevomeMedico);
            System.out.println("Médico creado: " + nuevomeMedico);
            
            // BUSCAR POR ID
            System.out.println("\n Buscando medico por ID " + nuevomeMedico.getIdMedico() + "...");
            Medico medicoEncontrado = medicoDAO.findById(nuevomeMedico.getIdMedico());
            if(medicoEncontrado!=null){
                System.out.println(" ## Medico encontrado: " + medicoEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró el paciente con el ID " + nuevomeMedico.getIdMedico());
            }

            // MODIFICAR 
            System.out.println("Modificar un medico");
            nuevomeMedico.setNombre("Carlos Mendez");
            int filasAfectadas1 = medicoDAO.update(nuevomeMedico);
            if(filasAfectadas1==1){
                System.out.println(" ## Medico " + nuevomeMedico.getIdMedico() + "actualizado correctamente");
                System.out.println(" ## Verificando actualización: " + medicoDAO.findById(nuevomeMedico.getIdMedico()));
            } else {
                System.err.println(" ¡¡ ERROR -  No se pudo actualizar el medico !!");
            }
            
            // LISTAR MEDICOS
            System.out.println("\n Listando todos los pacientes...");
            List<Medico> medicosTodos = medicoDAO.findAll();
            if(!medicosTodos.isEmpty()){
                System.out.println(" ## Medicos encontrados: " + medicosTodos.size());
                medicosTodos.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron Medicos");
            }

            

            // ======= MEDICAMENTO =======
            System.out.println("\n>>> Test MedicamentoDAO");
            Medicamento nuevoMedicamento = new Medicamento(1, "Ibuprofeno", "Ibuprofeno", "Analgésico", "Comprimidos");
            medicamentoDAO.create(nuevoMedicamento);
            System.out.println("Medicamento creado: " + nuevoMedicamento);

            // BUSCAR POR ID
            System.out.println("\n Buscando medicamento por ID " + nuevoMedicamento.getIdMedicamento() + "...");
            Medicamento medicamentoEncontrado = medicamentoDAO.findById(nuevoMedicamento.getIdMedicamento());
            if(medicamentoEncontrado != null){
                System.out.println(" ## Medicamento encontrado: " + medicamentoEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró el medicamento con el ID " + nuevoMedicamento.getIdMedicamento());
            }

            // MODIFICAR
            System.out.println("Modificar un medicamento...");
            nuevoMedicamento.setDescripcion("Analgésico y antipirético de uso común");
            int filasAfectadas2 = medicamentoDAO.update(nuevoMedicamento);
            if(filasAfectadas2 == 1){
                System.out.println(" ## Medicamento " + nuevoMedicamento.getIdMedicamento() + " actualizado correctamente");
                System.out.println(" ## Verificando actualización: " + medicamentoDAO.findById(nuevoMedicamento.getIdMedicamento()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo actualizar el medicamento !!");
            }

            // LISTAR TODOS LOS MEDICAMENTOS
            System.out.println("\n Listando todos los medicamentos...");
            List<Medicamento> medicamentosTodos = medicamentoDAO.findAll();
            if(!medicamentosTodos.isEmpty()){
                System.out.println(" ## Medicamentos encontrados: " + medicamentosTodos.size());
                medicamentosTodos.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontraron medicamentos");
            }

    
            // ======= RECETA =======
            System.out.println("\n>>> Test RecetaDAO");
            Receta nuevaReceta = new Receta(0, LocalDate.now(), "Dolor de cabeza", nuevomeMedico.getIdMedico(), nuevoPaciente.getIdPaciente());
            recetaDAO.create(nuevaReceta);
            System.out.println("Receta creada: " + nuevaReceta);

            // BUSCAR POR ID
            System.out.println("\nBuscando receta por ID " + nuevaReceta.getIdReceta() + "...");
            Receta recetaEncontrada = recetaDAO.findById(nuevaReceta.getIdReceta());
            if (recetaEncontrada != null) {
                System.out.println(" ## Receta encontrada: " + recetaEncontrada);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró la receta con el ID " + nuevaReceta.getIdReceta());
            }


            // MODIFICAR
            System.out.println("Modificar una receta...");
            nuevaReceta.setDiagnostico("Dolor de cabeza y fiebre"); 
            int filasAfectadas3 = recetaDAO.update(nuevaReceta);
            if (filasAfectadas3 == 1) {
                System.out.println(" ## Receta " + nuevaReceta.getIdReceta() + " actualizada correctamente");
                System.out.println(" ## Verificando actualización: " + recetaDAO.findById(nuevaReceta.getIdReceta()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo actualizar la receta !!");
            }

            // LISTAR TODAS LAS RECETAS
            System.out.println("\nListando todas las recetas...");
            List<Receta> recetasTodas = recetaDAO.findAll();
            if (!recetasTodas.isEmpty()) {
                System.out.println(" ## Recetas encontradas: " + recetasTodas.size());
                recetasTodas.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontraron recetas");
            }

            
            // ======= RECETA-MEDICAMENTO =======
            System.out.println("\n>>> Test RecetaMedicamentoDAO");
            RecetaMedicamento nuevaRM = new RecetaMedicamento(nuevaReceta.getIdReceta(), nuevoMedicamento.getIdMedicamento(), "500mg", "5 días");
            recetaMedDAO.create(nuevaRM);
            System.out.println("RecetaMedicamento creada: " + nuevaRM);

            // MODIFICAR
            System.out.println("Modificar relación receta-medicamento...");
            nuevaRM.setDosis("2 comprimidos cada 12 hs");
            nuevaRM.setDuracion("7 días");
            int filasAfectadas4 = recetaMedDAO.update(nuevaRM);
            if (filasAfectadas4 == 1) {
                System.out.println(" ## Relación actualizada correctamente");
                System.out.println(" ## Verificando actualización: " + recetaMedDAO.findById(nuevaRM.getIdReceta(), nuevaRM.getIdMedicamento()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo actualizar la relación !!");
            }

            // LISTAR TODAS LAS RECETAS-MEDICAMENTO
            System.out.println("\nListando todas las relaciones receta-medicamento...");
            List<RecetaMedicamento> relaciones = recetaMedDAO.findAll();
            if (!relaciones.isEmpty()) {
                System.out.println(" ## Relaciones encontradas: " + relaciones.size());
                relaciones.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontraron relaciones receta-medicamento");
            }

            
            /*
            // ======= TURNO =======
            System.out.println("\n>>> Test TurnoDAO");
            Turno nuevoTurno = new Turno(0, LocalDate.now(), Horario.H_9_00, "Chequeo general", nuevoPaciente.getIdPaciente(), nuevomeMedico.getIdMedico());
            turnoDAO.create(nuevoTurno);
            System.out.println("Turno creado: " + nuevoTurno);

            // BUSCAR POR ID
            System.out.println("\nBuscando turno por ID " + nuevoTurno.getIdTurno() + "...");
            Turno turnoEncontrado = turnoDAO.findById(nuevoTurno.getIdTurno());
            if (turnoEncontrado != null) {
                System.out.println(" ## Turno encontrado: " + turnoEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró el turno con ID " + nuevoTurno.getIdTurno());
            }

            // MODIFICAR turno
            System.out.println("\nModificando turno...");
            nuevoTurno.setHorario(Horario.H_10_00);  // cambiar horario
            int filasAfectadas5 = turnoDAO.update(nuevoTurno);
            if (filasAfectadas5 == 1) {
                System.out.println(" ## Turno " + nuevoTurno.getIdTurno() + " actualizado correctamente");
                System.out.println(" ## Verificando actualización: " + turnoDAO.findById(nuevoTurno.getIdTurno()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo actualizar el turno !!");
            }

            // LISTAR TODOS LOS TURNOS
            System.out.println("\nListando todos los turnos...");
            List<Turno> turnos = turnoDAO.findAll();
            if (!turnos.isEmpty()) {
                System.out.println(" ## Turnos encontrados: " + turnos.size());
                turnos.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontraron turnos");
            }

            // ELIMINAR turno
            System.out.println("\nEliminando turno " + nuevoTurno.getIdTurno() + "...");
            int filasAfectadasDelete = turnoDAO.delete(nuevoTurno.getIdTurno());
            if (filasAfectadasDelete == 1) {
                System.out.println(" ## Turno eliminado correctamente");
                System.out.println("Verificando eliminación: " + turnoDAO.findById(nuevoTurno.getIdTurno()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo eliminar el turno !!");
            }
             */

            // ELIMINAR relación
            System.out.println("\nEliminando relación receta-medicamento...");
            int filasAfectadasDelete1 = recetaMedDAO.delete(nuevaRM.getIdReceta(), nuevaRM.getIdMedicamento());
            if (filasAfectadasDelete1 == 1) {
                System.out.println(" ## Relación eliminada correctamente");
                System.out.println("Verificando eliminación: " + recetaMedDAO.findById(nuevaRM.getIdReceta(), nuevaRM.getIdMedicamento()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo eliminar la relación !!");
            }

            // ELIMINAR MEDICAMENTO
            System.out.println("\nEliminando medicamento " + nuevoMedicamento.getIdMedicamento() + "...");
            int filasAfectadasDelete2 = medicamentoDAO.delete(nuevoMedicamento.getIdMedicamento());
            if(filasAfectadasDelete2 == 1){
                System.out.println(" ## Medicamento " + nuevoMedicamento.getIdMedicamento() + " eliminado correctamente");
                System.out.println("Verificando eliminación: " + medicamentoDAO.findById(nuevoMedicamento.getIdMedicamento()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo eliminar el medicamento !!");
            }

            // ELIMINAR RECETA
            System.out.println("\nEliminando receta " + nuevaReceta.getIdReceta() + "...");
            int filasAfectadasDelete3 = recetaDAO.delete(nuevaReceta.getIdReceta());
            if (filasAfectadasDelete3 == 1) {
                System.out.println(" ## Receta " + nuevaReceta.getIdReceta() + " eliminada correctamente");
                System.out.println("Verificando eliminación: " + recetaDAO.findById(nuevaReceta.getIdReceta()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo eliminar la receta !!");
            }

            // ELIMINAR PACIENTE
            System.out.println("\nEliminando Paciente " + nuevoPaciente.getIdPaciente() + "...");
            int filasAfectadasDelete4 = pacienteDAO.delete(nuevoPaciente.getIdPaciente());
            if(filasAfectadasDelete4==1){
                System.out.println(" ## Paciente " + nuevoPaciente.getIdPaciente() + " eliminado correctamente");
                System.out.println("Verificando eliminación: " + pacienteDAO.findById(nuevoPaciente.getIdPaciente()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo eliminar al alumno !!");
            }

            // ELIMINAR MEDICO
            System.out.println("\nEliminando Medico " + nuevomeMedico.getIdMedico() + "...");
            int filasAfectadasDelete5 = medicoDAO.delete(nuevomeMedico.getIdMedico());
            if(filasAfectadasDelete5==1){
                System.out.println(" ## Medico " + nuevomeMedico.getIdMedico() + " eliminado correctamente");
                System.out.println("Verificando eliminación: " + medicoDAO.findById(nuevomeMedico.getIdMedico()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo eliminar el medico !!");
            }

            } catch (Exception e) {
            System.err.println("¡¡ ERROR DURANTE LAS PRUEBAS !!");
            e.printStackTrace();
            }
    }
}
