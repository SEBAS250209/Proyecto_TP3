
package clinica_medica.com.ar.entities;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Receta {
private int idReceta;
private LocalDate fechaEmision;
private String diagnostico;
private int idMedico;
private int idPaciente;

}
