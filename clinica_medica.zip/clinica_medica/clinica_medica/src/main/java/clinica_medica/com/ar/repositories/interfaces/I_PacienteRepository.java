package clinica_medica.com.ar.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import clinica_medica.com.ar.entities.Paciente;

public interface I_PacienteRepository {
    void create(Paciente paciente) throws SQLException;
    Paciente findById(int id) throws SQLException;
    List<Paciente> findAll() throws SQLException;
    int update(Paciente paciente) throws SQLException;
    int delete(int id) throws SQLException;
}
