package clinica_medica.com.ar.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import clinica_medica.com.ar.entities.Medico;
import clinica_medica.com.ar.repositories.interfaces.I_MedicoRepository;

@Repository
public class MedicoDAO implements I_MedicoRepository {

   private final DataSource dataSource ;
     
   private static final String SQL_CREATE = 
      "INSERT INTO medicos (nombre, apellido, dni, especialidad, matricula, tel_celular, email) values (?,?,?,?,?,?,?)";
   private static final String SQL_FIND_BY_ID =
      "SELECT * FROM medicos WHERE id_medico=?";
   private static final String SQL_FIND_ALL = 
      "SELECT * FROM medicos";
   private static final String SQL_UPDATE =
      "UPDATE medicos SET nombre=?, apellido=?, dni=?, especialidad=?, matricula=?, tel_celular=?, email=? WHERE id_medico=?";
   private static final String SQL_DELETE = 
      "DELETE FROM medicos WHERE id_medico=?";
     
   public MedicoDAO(DataSource dataSource) {
      this.dataSource = dataSource;
     }

     @Override
     public void create(Medico medico) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, medico.getNombre());
                ps.setString(2, medico.getApellido());
                ps.setString(3, medico.getDni());
                ps.setString(4, medico.getEspecialidad());
                ps.setInt(5, medico.getMatricula());
                ps.setString(6, medico.getTelCelular());
                ps.setString(7, medico.getEmail());
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if(keys.next()){
                        medico.setIdMedico(keys.getInt(1));
                }
            } 
        } 
     }

     @Override
     public Medico findById(int idMedico) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, idMedico);
            try (ResultSet rs = ps.executeQuery()) {
                if(rs.next()){
                    return mapRow(rs);
                }
            } 
        } 
        return null;
     }

     @Override
     public List<Medico> findAll() throws SQLException {
        List<Medico> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
               PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
               ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
               lista.add(mapRow(rs));
            }
        }
        return lista;
     }

     @Override
     public int update(Medico medico) throws SQLException {
         try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {

            ps.setString(1, medico.getNombre());
            ps.setString(2, medico.getApellido());
            ps.setString(3, medico.getDni());
            ps.setString(4, medico.getEspecialidad());
            ps.setInt(5, medico.getMatricula());
            ps.setString(6, medico.getTelCelular());
            ps.setString(7, medico.getEmail());
            ps.setInt(8, medico.getIdMedico());
            int filasAfectadas = ps.executeUpdate(); 
            return filasAfectadas; 
        }
     }

     @Override
     public int delete(int idMedico) throws SQLException {
         try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, idMedico);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        } 
     }

      private Medico mapRow(ResultSet rs) throws SQLException{
        Medico medico = new Medico();
        medico.setIdMedico(rs.getInt("id_medico"));
        medico.setNombre(rs.getString("nombre"));
        medico.setApellido(rs.getString("apellido"));
        medico.setDni(rs.getString("dni"));
        medico.setEspecialidad(rs.getString("especialidad"));
        medico.setMatricula(rs.getInt("matricula"));
        medico.setTelCelular((rs.getString("tel_celular")));
        medico.setEmail((rs.getString("email")));
        return medico;
    }

     

}
