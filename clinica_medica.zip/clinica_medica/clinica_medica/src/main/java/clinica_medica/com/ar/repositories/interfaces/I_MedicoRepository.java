package clinica_medica.com.ar.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import clinica_medica.com.ar.entities.Medico;

public interface I_MedicoRepository {
    void create(Medico medico) throws SQLException;
    Medico findById(int id) throws SQLException;
    List<Medico> findAll() throws SQLException;
    int update(Medico medico) throws SQLException;
    int delete(int id) throws SQLException;
}
