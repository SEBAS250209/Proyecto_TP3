package clinica_medica.com.ar.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Medico {
private int idMedico;
private String nombre;
private String apellido;
private String dni;
private String especialidad;
private int matricula;
private String telCelular;
private String email;
}
