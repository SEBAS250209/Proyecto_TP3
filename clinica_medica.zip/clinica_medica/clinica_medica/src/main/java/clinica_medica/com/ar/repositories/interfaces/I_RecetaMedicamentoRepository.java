package clinica_medica.com.ar.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import clinica_medica.com.ar.entities.RecetaMedicamento;

public interface I_RecetaMedicamentoRepository{
    void create(RecetaMedicamento recetaMedicamento) throws SQLException;
    RecetaMedicamento findById(int idReceta, int idMedicamento) throws SQLException;
    List<RecetaMedicamento> findAll() throws SQLException;
    int update(RecetaMedicamento recetaMedicamento) throws SQLException;
    List<RecetaMedicamento> findByIdReceta(int idReceta) throws SQLException;
    int delete(int idReceta, int idMedicamento) throws SQLException;

}
