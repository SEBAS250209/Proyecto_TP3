package clinica_medica.com.ar.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import clinica_medica.com.ar.entities.Receta;

public interface I_RecetaRepository {
    void create(Receta receta) throws SQLException;
    Receta findById(int id) throws SQLException;
    List<Receta> findAll() throws SQLException;
    int update(Receta receta) throws SQLException;
    int delete(int id) throws SQLException;   
    List<Receta> findByIdPaciente(int idPaciente) throws SQLException;
    List<Receta> findByIdMedico(int idMedico) throws SQLException;
}
