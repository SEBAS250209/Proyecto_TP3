package clinica_medica.com.ar.repositories.interfaces;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import clinica_medica.com.ar.entities.Turno;

public interface I_TurnoRepository {
    void create(Turno turno) throws SQLException;
    Turno findById(int id) throws SQLException;
    List<Turno> findAll() throws SQLException;
    int update(Turno turno) throws SQLException;
    int delete(int id) throws SQLException;
    List<Turno> findByIdMedico(int idMedico) throws SQLException;
    List<Turno> findByIdPaciente(int idPaciente) throws SQLException;
    List<Turno> findByFecha(LocalDate fecha) throws SQLException;
}
