package clinica_medica.com.ar.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Paciente {
private int idPaciente;
private String nombre;
private String apellido;
private String genero;
private int dni;
private String telCelular;
private String email;
private int idHistoria;
private String obraSocial;
}
