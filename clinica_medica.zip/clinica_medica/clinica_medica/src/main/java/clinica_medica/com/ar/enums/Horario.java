package clinica_medica.com.ar.enums;

public enum Horario {
    
	H_8_00("08:00"),
    H_8_30("08:30"),
    H_9_00("09:00"),
    H_9_30("09:30"),
    H_10_00("10:00"),
    H_10_30("10:30"),
    H_11_00("11:00"),
    H_11_30("11:30"),
    H_12_00("12:00"),
    H_12_30("12:30"),
    H_13_00("13:00");

    private final String hora;

    Horario(String hora) {
        this.hora = hora;
    }

    public String getHora() {
        return hora;
    }
}
