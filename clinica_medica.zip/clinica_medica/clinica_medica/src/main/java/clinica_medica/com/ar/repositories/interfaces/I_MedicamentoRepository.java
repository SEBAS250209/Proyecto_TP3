package clinica_medica.com.ar.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import clinica_medica.com.ar.entities.Medicamento;

public interface I_MedicamentoRepository {
    void create(Medicamento medicamento) throws SQLException;
    Medicamento findById(int id) throws SQLException;
    List<Medicamento> findAll() throws SQLException;
    int update(Medicamento medicamento) throws SQLException;
    int delete(int id) throws SQLException;
    List<Medicamento> findByDroga(String droga) throws SQLException;
}
