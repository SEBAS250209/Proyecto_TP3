package clinica_medica.com.ar.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class RecetaMedicamento {
private int idReceta;
private int idMedicamento;
private String dosis;
private String duracion;

}
