package clinica_medica.com.ar.entities;

import java.time.LocalDate;

import clinica_medica.com.ar.enums.Horario;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Turno {
private int idTurno;
private LocalDate fecha;
private Horario horario;
private String motivo;
private int idMedico;
private int idPaciente;

}
