package clinica_medica.com.ar.repositories;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import clinica_medica.com.ar.entities.Turno;
import clinica_medica.com.ar.enums.Horario;
import clinica_medica.com.ar.repositories.interfaces.I_TurnoRepository;

@Repository
public class TurnoDAO implements I_TurnoRepository{

    private final DataSource dataSource;

    private static final String SQL_CREATE =
        "INSERT INTO turnos (fecha, horario, motivo, id_paciente, id_medico) VALUES (?, ?, ?, ?, ?)";
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM turnos WHERE id_turno = ?";
    private static final String SQL_FIND_ALL =
        "SELECT * FROM turnos";
    private static final String SQL_UPDATE =
        "UPDATE turnos SET fecha = ?, horario = ?, motivo = ?, id_paciente = ?, id_medico = ? WHERE id_turno = ?";
    private static final String SQL_DELETE =
        "DELETE FROM turnos WHERE id_turno = ?";
    private static final String SQL_FIND_BY_ID_MEDICO =
        "SELECT * FROM turnos WHERE id_medico = ?";
    private static final String SQL_FIND_BY_ID_PACIENTE =
        "SELECT * FROM turnos WHERE id_paciente = ?";
    private static final String SQL_FIND_BY_FECHA =
        "SELECT * FROM turnos WHERE fecha = ?";

    public TurnoDAO(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(Turno turno) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {

            ps.setDate(1, Date.valueOf(turno.getFecha()));
            ps.setString(2, turno.getHorario().toString());
            ps.setString(3, turno.getMotivo());
            ps.setInt(4, turno.getIdPaciente());
            ps.setInt(5, turno.getIdMedico());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    turno.setIdTurno(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Turno findById(int idTurno) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, idTurno);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Turno> findAll() throws SQLException {
        List<Turno> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        }
        return lista;
    }

    @Override
    public int update(Turno turno) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {

            ps.setDate(1, Date.valueOf(turno.getFecha()));
            ps.setString(2, turno.getHorario().toString());
            ps.setString(3, turno.getMotivo());
            ps.setInt(4, turno.getIdPaciente());
            ps.setInt(5, turno.getIdMedico());
            ps.setInt(6, turno.getIdTurno());

            return ps.executeUpdate();
        }
    }

    @Override
    public int delete(int idTurno) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {

            ps.setInt(1, idTurno);
            return ps.executeUpdate();
        }
    }

    @Override
    public List<Turno> findByIdMedico(int idMedico) throws SQLException {
        List<Turno> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID_MEDICO)) {

            ps.setInt(1, idMedico);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    @Override
    public List<Turno> findByIdPaciente(int idPaciente) throws SQLException {
        List<Turno> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID_PACIENTE)) {

            ps.setInt(1, idPaciente);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    @Override
    public List<Turno> findByFecha(LocalDate fecha) throws SQLException {
        List<Turno> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_FECHA)) {

            ps.setDate(1, Date.valueOf(fecha));

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    private Turno mapRow(ResultSet rs) throws SQLException {
        Turno turno = new Turno();
        turno.setIdTurno(rs.getInt("id_turno"));
        turno.setFecha(rs.getDate("fecha").toLocalDate());
        turno.setHorario(Horario.valueOf(rs.getString("horario")));
        turno.setMotivo(rs.getString("motivo"));
        turno.setIdPaciente(rs.getInt("id_paciente"));
        turno.setIdMedico(rs.getInt("id_medico"));
        return turno;
    }

}
