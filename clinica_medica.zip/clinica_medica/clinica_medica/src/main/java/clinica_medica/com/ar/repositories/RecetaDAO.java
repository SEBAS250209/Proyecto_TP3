package clinica_medica.com.ar.repositories;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import clinica_medica.com.ar.entities.Receta;
import clinica_medica.com.ar.repositories.interfaces.I_RecetaRepository;

@Repository
public class RecetaDAO implements I_RecetaRepository{

    private final DataSource dataSource;

    private static final String SQL_CREATE =
        "INSERT INTO recetas (fecha_emision, diagnostico, id_medico, id_paciente) VALUES (?, ?, ?, ?)";
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM recetas WHERE id_receta = ?";
    private static final String SQL_FIND_ALL =
        "SELECT * FROM recetas";
    private static final String SQL_UPDATE =
        "UPDATE recetas SET fecha_emision = ?, diagnostico = ?, id_medico = ?, id_paciente = ? WHERE id_receta = ?";
    private static final String SQL_DELETE =
        "DELETE FROM recetas WHERE id_receta = ?";
    private static final String SQL_FIND_BY_ID_PACIENTE =
        "SELECT * FROM recetas WHERE id_paciente = ?";
    private static final String SQL_FIND_BY_ID_MEDICO =
        "SELECT * FROM recetas WHERE id_medico = ?";

    public RecetaDAO(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(Receta receta) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setDate(1, Date.valueOf(receta.getFechaEmision()));
            ps.setString(2, receta.getDiagnostico());
            ps.setInt(3, receta.getIdMedico());
            ps.setInt(4, receta.getIdPaciente());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    receta.setIdReceta(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Receta findById(int idReceta) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, idReceta);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Receta> findAll() throws SQLException {
        List<Receta> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        }
        return lista;
    }

    @Override
    public int update(Receta receta) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setDate(1, Date.valueOf(receta.getFechaEmision()));
            ps.setString(2, receta.getDiagnostico());
            ps.setInt(3, receta.getIdMedico());
            ps.setInt(4, receta.getIdPaciente());
            ps.setInt(5, receta.getIdReceta());
            return ps.executeUpdate();
        }
    }

    @Override
    public int delete(int idReceta) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, idReceta);
            return ps.executeUpdate();
        }
    }

    @Override
    public List<Receta> findByIdPaciente(int idPaciente) throws SQLException {
        List<Receta> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID_PACIENTE)) {
            ps.setInt(1, idPaciente);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    @Override
    public List<Receta> findByIdMedico(int idMedico) throws SQLException {
        List<Receta> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
            PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID_MEDICO)) {
            ps.setInt(1, idMedico);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    private Receta mapRow(ResultSet rs) throws SQLException {
        Receta receta = new Receta();
        receta.setIdReceta(rs.getInt("id_receta"));
        receta.setFechaEmision(rs.getDate("fecha_emision").toLocalDate());
        receta.setDiagnostico(rs.getString("diagnostico"));
        receta.setIdMedico(rs.getInt("id_medico"));
        receta.setIdPaciente(rs.getInt("id_paciente"));
        return receta;
    }
}


