package clinica_medica.com.ar.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import clinica_medica.com.ar.entities.RecetaMedicamento;
import clinica_medica.com.ar.repositories.interfaces.I_RecetaMedicamentoRepository;

@Repository
public class RecetaMedicamentoDAO implements I_RecetaMedicamentoRepository {
    private final DataSource dataSource;

    private static final String SQL_CREATE =
        "INSERT INTO recetas_medicamentos (id_receta, id_medicamento, dosis, duracion) VALUES (?, ?, ?, ?)";
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM recetas_medicamentos WHERE id_receta = ? AND id_medicamento = ?";
    private static final String SQL_FIND_ALL =
        "SELECT * FROM recetas_medicamentos";
    private static final String SQL_UPDATE =
        "UPDATE recetas_medicamentos SET dosis = ?, duracion = ? WHERE id_receta = ? AND id_medicamento = ?";
    private static final String SQL_FIND_BY_ID_RECETA =
        "SELECT * FROM recetas_medicamentos WHERE id_receta = ?";
    private static final String SQL_DELETE =
        "DELETE FROM recetas_medicamentos WHERE id_receta = ? AND id_medicamento = ?";

    public RecetaMedicamentoDAO(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(RecetaMedicamento rm) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE)) {
            ps.setInt(1, rm.getIdReceta());
            ps.setInt(2, rm.getIdMedicamento());
            ps.setString(3, rm.getDosis());
            ps.setString(4, rm.getDuracion());
            ps.executeUpdate();
        }
    }

    @Override
    public RecetaMedicamento findById(int idReceta, int idMedicamento) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, idReceta);
            ps.setInt(2, idMedicamento);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<RecetaMedicamento> findAll() throws SQLException {
        List<RecetaMedicamento> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        }
        return lista;
    }

    @Override
    public int update(RecetaMedicamento rm) throws SQLException {
        try (Connection conn = dataSource.getConnection();
            PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, rm.getDosis());
            ps.setString(2, rm.getDuracion());
            ps.setInt(3, rm.getIdReceta());
            ps.setInt(4, rm.getIdMedicamento());
            return ps.executeUpdate();
        }
    }

    @Override
    public List<RecetaMedicamento> findByIdReceta(int idReceta) throws SQLException {
        List<RecetaMedicamento> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID_RECETA)) {
            ps.setInt(1, idReceta);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    @Override
    public int delete(int idReceta, int idMedicamento) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, idReceta);
            ps.setInt(2, idMedicamento);
            return ps.executeUpdate();
        }
    }

    private RecetaMedicamento mapRow(ResultSet rs) throws SQLException {
        RecetaMedicamento rm = new RecetaMedicamento();
        rm.setIdReceta(rs.getInt("id_receta"));
        rm.setIdMedicamento(rs.getInt("id_medicamento"));
        rm.setDosis(rs.getString("dosis"));
        rm.setDuracion(rs.getString("duracion"));
        return rm;
    }
}
