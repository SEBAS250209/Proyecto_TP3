

INSERT INTO pacientes (nombre, apellido, genero, dni, tel_celular, email, id_historia , obra_social) VALUES
('María', 'González', 'Femenino', '12345678', '1134567890', 'maria@gmail.com', 1 , 'OSDE'),
('Juan', 'Pérez', 'Masculino', '87654321', '1198765432', 'juanp@gmail.com', 2, 'Swiss Medical'),
('Ana', 'Martínez', 'Femenino', '23456789', '1167891234', 'ana.martinez@gmail.com', 3 , 'Galeno'),
('Pedro', 'Ramírez', 'Masculino', '34567890', '1156789012', 'pedro.ramirez@yahoo.com', 4 , 'OSDE'),
('Lucía', 'Fernández', 'Femenino', '45678901', '1145678901', 'lucia.fernandez@hotmail.com',5 , 'PAMI'),
('Sofía', 'López', 'Femenino', '56789012', '1178901234', 'sofia.lopez@gmail.com', 6, 'Medicus'),
('Diego', 'Gutiérrez', 'Masculino', '67890123', '1187654321', 'diego.gutierrez@gmail.com', 7, 'IOMA');

INSERT INTO medicos (nombre, apellido, dni, especialidad, matricula, tel_celular, email) VALUES
('Laura', 'Ramírez', '11223344', 'Clínica Médica', 10001, '1154321098', 'laura.ramirez@hospital.com'),
('Carlos', 'Fernández', '44332211', 'Cardiología', 10002, '1167894321', 'carlos.fernandez@hospital.com'),
('Mónica', 'Suárez', '22334455', 'Pediatría', 10003, '1176543210', 'monica.suarez@hospital.com'),
('Daniel', 'Torres', '33445566', 'Neurología', 10004, '1143210987', 'daniel.torres@hospital.com'),
('Luciano', 'Gómez', '44556677', 'Dermatología', 10005, '1132109876', 'luciano.gomez@hospital.com'),
('Verónica', 'Silva', '55667788', 'Ginecología', 10006, '1123456789', 'veronica.silva@hospital.com'),
('Roberto', 'Álvarez', '66778899', 'Traumatología', 10007, '1112345678', 'roberto.alvarez@hospital.com');

INSERT INTO turnos (fecha, horario, motivo, id_paciente, id_medico) VALUES
('2025-06-14', '10:00', 'Control de presión', 1, 1),
('2025-06-14', '10:30', 'Chequeo general', 2, 1),
('2025-06-15', '9:00', 'Consulta respiratoria', 3, 3),
('2025-06-15', '9:30', 'Dolor de cabeza', 4, 4),
('2025-06-16', '8:00', 'Dermatitis', 5, 5),
('2025-06-16', '11:00', 'Control ginecológico', 6, 6),
('2025-06-17', '12:30', 'Dolor de rodilla', 7, 7);

INSERT INTO recetas (fecha_emision, diagnostico, id_medico, id_paciente) VALUES
('2025-06-14', 'Hipertensión estable', 1, 1),
('2025-06-14', 'Chequeo sin hallazgos', 1, 2),
('2025-06-15', 'Bronquitis leve', 3, 3),
('2025-06-15', 'Migraña frecuente', 4, 4),
('2025-06-16', 'Eczema crónico', 5, 5),
('2025-06-16', 'Chequeo de rutina', 6, 6),
('2025-06-17', 'Tendinitis en rodilla', 7, 7);

INSERT INTO medicamentos (id_medicamento, nombre_comercial, droga, descripcion, presentacion) VALUES
(1,'Losartán', 'Losartán potásico', 'Antihipertensivo', 'Caja con 30 comprimidos'),
(2, 'Paracetamol', 'Paracetamol', 'Analgésico y antipirético', 'Caja con 20 comprimidos'),
(3, 'Salbutamol', 'Salbutamol', 'Broncodilatador', 'Inhalador 100 dosis'),
(4, 'Ibuprofeno', 'Ibuprofeno', 'Antiinflamatorio', 'Caja con 10 tabletas'),
(5, 'Clotrimazol', 'Clotrimazol', 'Antifúngico tópico', 'Crema 30g'),
(6, 'Ácido fólico', 'Ácido fólico', 'Suplemento vitamínico', 'Caja con 60 comprimidos'),
(7, 'Diclofenac', 'Diclofenac sódico', 'Antiinflamatorio no esteroideo', 'Caja con 15 comprimidos');

INSERT INTO recetas_medicamentos (id_receta, id_medicamento, dosis, duracion) VALUES
(1, 1, '50mg cada 12h', '30 días'),
(2, 2, '500mg cada 8h', '3 días'),
(3, 3, '2 puff cada 6h', '5 días'),
(4, 4, '400mg cada 6h', '7 días'),
(5, 5, 'Aplicar 2 veces al día', '10 días'),
(6, 6, '1 comprimido por día', '3 meses'),
(7, 7, '50mg cada 8h', '14 días');					