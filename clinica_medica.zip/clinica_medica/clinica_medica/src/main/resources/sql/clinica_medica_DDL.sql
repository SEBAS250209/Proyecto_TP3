

create table pacientes(
id_paciente int auto_increment,
nombre varchar(50) not null ,
apellido varchar(50) not null,
genero varchar (50) not null ,
dni char (8) not null,
tel_celular varchar(10) not null,
email varchar (50) not null,
id_historia int not null,
obra_social  varchar (100) not null,
primary key (id_paciente)
); 

create table medicos(
id_medico int auto_increment,
nombre varchar(50) not null,
apellido varchar(50) not null,
dni char(8) not null,
especialidad varchar (100) not null,
matricula int not null,
tel_celular varchar(10) not null,
email varchar (50) not null,
primary key(id_medico)
);

create table recetas(
id_receta int auto_increment,
fecha_emision date not null,
diagnostico varchar(300) not null,
id_medico int not null,
id_paciente int not null,
primary key(id_receta)
);

alter table recetas 
add constraint Fk_recetas_pacientes
foreign key (id_paciente)
references pacientes(id_paciente);

alter table recetas 
add constraint Fk_recetas_medicos
foreign key (id_medico)
references medicos(id_medico);

create table turnos(
id_turno int auto_increment,
fecha date not null,
horario ENUM('8:00','8:30','9:00','9:30',
			'10:00','10:30','11:00','11:30',
			'12:00','12:30','13:00'),
motivo varchar (50) not null,
id_paciente int not null,
id_medico int not null,
primary key(id_turno)
);

alter table turnos
add constraint FK_turnos_pacientes
foreign key (id_paciente)
references pacientes(id_paciente);

alter table turnos 
add constraint Fk_turnos_medicos
foreign key (id_medico)
references medicos(id_medico);

create table medicamentos(
id_medicamento int ,
nombre_comercial varchar(100) not null,
droga varchar(100),
descripcion varchar(100) not null,
presentacion varchar(100) not null,
primary key(id_medicamento)
);

create table recetas_medicamentos(
id_receta int not null,
id_medicamento int not null,
dosis varchar(100) not null,
duracion varchar(50) not null,
primary key(id_receta,id_medicamento)
);

alter table recetas_medicamentos 
add constraint Fk_recetas_medicamentos_recetas
foreign key (id_receta)
references recetas(id_receta);

alter table recetas_medicamentos 
add constraint Fk_recetas_medicamentos_medicamentos
foreign key (id_medicamento)
references medicamentos(id_medicamento)