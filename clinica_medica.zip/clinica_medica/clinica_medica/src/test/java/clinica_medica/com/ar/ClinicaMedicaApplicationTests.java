package clinica_medica.com.ar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicaMedicaApplicationTests {

	@Test
	void contextLoads() {
	}

}
